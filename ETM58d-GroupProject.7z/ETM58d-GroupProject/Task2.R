library(tidyverse)
library(ggplot2)
getwd()
setwd("C:/Users/YUKSELI/Desktop")
list.files()
veri<- read.csv("tr_super_league_odd_details.csv")
veri

veri1 <- veri %>% mutate(Phome = 1/HomeOdd,Paway= 1/AwayOdd, Ptie = 1/TieOdd )

veri1

veri2 <- veri %>% mutate(Pnhome = (1/HomeOdd)*(1/((1/HomeOdd)+(1/AwayOdd)+(1/TieOdd))) ,Pnaway= (1/AwayOdd)*(1/((1/HomeOdd)+(1/AwayOdd)+(1/TieOdd))),Pntie = (1/TieOdd)*(1/((1/HomeOdd)+(1/AwayOdd)+(1/TieOdd))))

veri2

veri3 <- veri1 %>% mutate(diff_prob = Phome - Paway)                                      

veri3

ggplot(data=veri3, aes(x=diff_prob, y=Ptie)) + geom_point(col="darkblue", fill="blue", alpha=.4) + labs(x="Phome - Paway")
