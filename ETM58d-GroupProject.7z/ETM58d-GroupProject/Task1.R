library(tidyverse)
library(ggplot2)
getwd()
setwd("D:/Users/SUUSER/Desktop")
list.files()
veri<- read.csv("tr_super_league_matches.csv"  )
veri
home <- ggplot(data=veri,aes(x= Home_Score)) + geom_histogram(col="darkgreen",fill= "green", alpha=.3)+ labs (title="Home Score Histogram", x="Home Score", y="number of events")

away <- ggplot(data=veri,aes(x= Away_Score)) + geom_histogram(col="darkgreen",fill= "green", alpha=.3)+ labs (title="Away Score Histogram", x="Away Score", y="number of events")

home
away

veri %>% mutate(diff_score=Home_Score - Away_Score) 

difference <- ggplot(data=veri %>% mutate(Difference_Score=Home_Score - Away_Score) ,aes(x=Difference_Score)) + geom_histogram(col="darkgreen",fill= "green", alpha=.3)+ labs (title="Score Difference Histogram", x="Score Difference", y="number of events")
difference
